                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2144971
Case for Stepper motor by circuito is licensed under the GNU - GPL license.
http://creativecommons.org/licenses/GPL/2.0/

# Summary

A 3D printed case for a Sparkfun stepper motor. It is perfect for rapid prototyping with this component and a nice addition to your circuito project https://goo.gl/M9Bz90

# Print Settings

Printer Brand: FlashForge
Printer: Creator Pro

Notes: 
Drill the holes with 1.7mm drill

# How I Designed This

The case was designed according to the specific dimensions of Sparkfun's stepper motor and can be used for any project made with this component. 
Here's an example of a project using the stepper motor https://www.hackster.io/circuito-io-team/arduino-bluetooth-controlled-mini-lift-ffffd9?team=36156

# Animated Gif

![Alt text](https://cdn.thingiverse.com/assets/40/4c/98/a6/e2/Stepper.gif)