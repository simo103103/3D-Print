                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2467743
Pan tilt head by eltitomanolo is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

Turret with horizontal and vertical movements powered by sg90 servos. IMPORTANT: You can choose the type of mounting the servos, with or without horns. Make sure you print the turret suitable for your needs. If you print  the type without horns: the connection between the servo shaft and the parts is performed by means of a conical housing, only the central screw is required. The arm and the support are joined by cyanoclite adhesive. Watch Mounting Video  

Torreta con movimientos horizontal y vertical accionada mediante servos tipo sg90. IMPORTANTE: Puede elegir el tipo de montaje de los servos, con o sin horns. Si imprime la versión sin horns la unión entre el eje del servo y las piezas se realiza mediante un alojamiento cónico, solo se requiere el tornillo central. El brazo y el soporte están unidos mediante adhesivo de cianoclitaro. Ver video de montaje

https://youtu.be/1Fyo4pMwyDI  https://youtu.be/_6-Wora5qNw https://www.youtube.com/watch?v=HB-rClhsuPo

# Print Settings

Printer: Anet A8

Notes: 
You must print the pieces at the position shown in the pictures. None needs support except the solar tracker accessory.

Debe imprimir las piezas en la posición que muestran las imágenes. Ninguna necesita soporte excepto el accesorio seguidor solar.

# Post-Printing

<iframe src="//www.youtube.com/embed/1Fyo4pMwyDI" frameborder="0" allowfullscreen></iframe>
Recording and playback of movements using an arduino

# How I Designed This

## In FreeCAD

I'll do a tutorial ... when I have time