                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:3023833
 by stevendpe is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

This is a servo motor controlled eyeball for use with the Pi Camera 2, though the eyeball part can be modified for most small cameras. See this video for more explanation and build details:
https://www.youtube.com/watch?v=K9PUCmdXlQc

Since you might be changing the eyeball for use with other cameras, I've included the Blender file (https://www.blender.org/) so you can modify it easily.

# Print Settings

Printer Brand: Creality
Printer: CR-10

Notes: 
Since these parts are so small and need strength, I used 100% infill. The raft was needed for some parts because the print head would sometimes knock them loose from the print bed once the print got tall enough.

eyeball_left_for_print
eyestructhoriz_left_for_print
Layer height: 0.20
Infill: 100%
Build Plate Adhesion Type: Raft
Raft Air Gap: 0.3 (default)

connecting_rod_and_horn_attachment_for_print
eyestructservotop_left_for_print
eyetmpservomount_left_for_print
Layer height: 0.20
Infill: 100%
Build Plate Adhesion Type: Skirt
Raft Air Gap: 0.3 (default)

Note that the OBJ and STL files were exported from Blender. Cura was able to open the OBJ file but not the STL. I assume this is a Blender issue.